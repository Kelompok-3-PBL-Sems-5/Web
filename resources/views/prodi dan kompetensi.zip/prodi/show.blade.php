@extends('layouts.template')
@section('content')
    <div class="card card-outline card-primary">
        <div class="card-header">
            <h3 class="card-title">{{ $page->title }}</h3>
            <div class="card-tools"></div>
        </div>
        <div class="card-body">
            @empty($prodi)
                <div class="alert alert-danger alert-dismissible">
                    <h5><i class="icon fas fa-ban"></i> Kesalahan!</h5>
                    Data yang Anda cari tidak ditemukan.
                </div>
            @else
                <table class="table table-bordered table-striped table-hover table-sm">
                    <tr>
                        <th>ID Prodi</th>
                        <td>{{ $prodi->id_prodi }}</td>
                    </tr>
                    <tr>
                        <th>Nama Prodi</th>
                        <td>{{ $prodi->nama_prodi }}</td>
                    </tr>
                    <tr>
                        <th>NIDN User</th>
                        <td>{{ $prodi->nidn_user }}</td>
                    </tr>
                    <tr>
                        <th>ID User</th>
                        <td>{{ $prodi->id_user }}</td>
                    </tr>
                    <tr>
                        <th>Kode Prodi</th>
                        <td>{{ $prodi->kode_prodi }}</td>
                    </tr>
                    <tr>
                        <th>Jenjang</th>
                        <td>{{ $prodi->jenjang }}</td>
                    </tr>
                </table>
            @endempty
            <a href="{{ url('prodi') }}" class="btn btn-sm btn-default mt-2">Kembali</a>
        </div>
    </div>
@endsection

@push('css')
@endpush

@push('js')
@endpush
